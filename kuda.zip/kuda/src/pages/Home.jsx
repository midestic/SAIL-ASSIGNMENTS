import React from "react";

export default function Home() {
  return (
    <div className="w-[100%] flex justify-center items-center">
      <div className="w-[70%] mt-[50px] h-[50vh] border bg-[#40196d] flex justify-center items-center">
        {" "}
        <p className="text-white text-[50px]">Homepage</p>{" "}
      </div>
    </div>
  );
}
