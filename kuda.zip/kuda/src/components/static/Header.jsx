export default function Header() {
  return (
    <div className="max-w-[1440px] mx-auto">
      <div></div>
    </div>
  );
}
